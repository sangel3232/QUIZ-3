package com.corhuila.BackendNoSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendNoSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendNoSqlApplication.class, args);
	}

}
