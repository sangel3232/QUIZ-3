package com.corhuila.BackendNoSQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendNoSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
