import { Injectable } from '@angular/core';
import { Proveedor } from '../model/proveedor';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProveedorService {
  proveedorURL = environment.apiResrURL + '/proveedor';

  constructor(private httpClient: HttpClient) {}
  
  public create(proveedor: Proveedor): Observable<Proveedor>{
    return this.httpClient.post<Proveedor>(this.proveedorURL, proveedor);
  }
}
