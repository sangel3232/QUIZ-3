import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Proveedor } from 'src/app/model/proveedor';
import { ProveedorService } from 'src/app/services/proveedor.service';

@Component({
  selector: 'app-proveedor',
  templateUrl: './proveedor.component.html',
  styleUrls: ['./proveedor.component.css'],
})
export class ProveedorComponent  implements OnInit {

  codigo!: number;
  nombre!: string;
  direccion!: string;
  
  constructor(
    private proveedorService: ProveedorService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    
  }

  async onCreate(): Promise<void> {
    const proveedor = new Proveedor(this.codigo, this.nombre, this.direccion); 
    try {
      await this.proveedorService.create(proveedor).toPromise();
      this.router.navigate(['libros']);
    } catch (error: any) {
    }
  }

}
