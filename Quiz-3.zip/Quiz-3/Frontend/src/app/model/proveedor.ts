export class Proveedor {
    identificacion!: string;
    codigo!: number 
    nombre!: string;
    direccion!: string;

    constructor(codigo: number, nombre: string, direccion: string){
        this.codigo = codigo;
        this.nombre = nombre;
        this.direccion = direccion;
    }
}
